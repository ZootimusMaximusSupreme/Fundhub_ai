# Climate page — Claude Chat attach pack (2026-09-18)

Zip this folder (or attach the files below) when you paste the brief in **Claude Chat** (outside Cursor). Do **not** attach `node_modules` or `public/climate/_next/` chunks.

**Live page:** https://fundhub.ai/climate/  
**Live API:** https://fundhub.ai/api/climate (CRM lender book + climate aggregates; no fake approval odds)

## What to attach

| Path | Why |
|------|-----|
| `darwin-source/app/lender-climate/_components/MapHero.jsx` | Interactive map / globe hero |
| `darwin-source/app/lender-climate/_components/ClimateShell.jsx` | Page shell around the map |
| `darwin-source/app/lender-climate/_components/AddressSearch.jsx` | Google geocode / location triangulation |
| `darwin-source/app/lender-climate/_components/USAMapSVG.jsx` | SVG map layer |
| `darwin-source/app/lender-climate/_styles/map.css` | Map / globe styling |
| `darwin-source/app/lender-climate/_styles/cards.css` | Panel / card styling |
| `darwin-source/app/lender-climate/page.jsx` | Main lender-climate route |
| `darwin-source/app/layout.jsx` | App layout |
| `darwin-source/app/globals.css` | Global styles |
| `darwin-source/lib/projection.js` | Lat/lng → map coordinates |
| `darwin-source/lib/climateClient.js` | Fetches `/api/climate` |
| `live-export/index.html` | Small static export shell (~5 KB) from commit `ca3bc190` — not the full `_next` bundle |
| `reference-soft-pull-approve.html` | Existing soft-pull authorization + identity fields (mirror these on the climate gate) |

Optional (if Claude needs full component context): the other files under `darwin-source/app/lender-climate/_components/` and `darwin-source/lib/`.

## Source of truth

Darwin dashboard unzip: `credentials/lender-climate-engine-gmail-2026-09-18/unzipped/Lender-Climate-Engine/fundhub-climate-dashboard` (gitignored credentials tree; this pack is the committed copy for chat).

**Prompt file (paste this too):** `docs/ads/climate-claude-chat-prompt-2026-09-18.md`
