import './globals.css';

export const metadata = {
  title: 'FundHub Lending Climate Dashboard',
  description: 'National to state to bank lending climate view.'
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
