import Link from 'next/link';

export default function Home() {
  return (
    <main style={{ padding: '2rem', fontFamily: 'Inter, system-ui, sans-serif' }}>
      <h1>FundHub Lending Climate Dashboard</h1>
      <p>Open the climate experience.</p>
      <Link href="/lender-climate">Go to Lender Climate →</Link>
    </main>
  );
}
