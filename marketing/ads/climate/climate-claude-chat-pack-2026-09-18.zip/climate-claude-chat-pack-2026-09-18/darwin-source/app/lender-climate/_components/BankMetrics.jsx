'use client';
import { useMemo, useState } from 'react';
import '../_styles/cards.css';
import { fmtScore } from '../../../lib/format';

export default function BankMetrics({ banks = [] }) {
  const [stateFilter, setStateFilter] = useState('');
  const [typeFilter, setTypeFilter] = useState('');

  const filtered = useMemo(() => {
    return banks
      .filter(b => (stateFilter ? b.state === stateFilter : true))
      .filter(b => (typeFilter ? b.type === typeFilter : true));
  }, [banks, stateFilter, typeFilter]);

  const topBanks = [...filtered].sort((a, b) => b.score - a.score).slice(0, 6);
  const states = Array.from(new Set(banks.map(b => b.state)));

  return (
    <section className="section">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 10 }}>
        <h3 style={{ margin: 0 }}>Bank Appetite</h3>
        <div style={{ display: 'flex', gap: 8 }}>
          <select value={stateFilter} onChange={(e) => setStateFilter(e.target.value)} className="pill" style={{ color: '#e2e8f0', background: 'rgba(255,255,255,0.05)' }}>
            <option value="">All states</option>
            {states.map((s) => <option key={s} value={s}>{s}</option>)}
          </select>
          <select value={typeFilter} onChange={(e) => setTypeFilter(e.target.value)} className="pill" style={{ color: '#e2e8f0', background: 'rgba(255,255,255,0.05)' }}>
            <option value="">All types</option>
            <option value="bank">Bank</option>
            <option value="cu">CU</option>
            <option value="fintech">Fintech</option>
          </select>
        </div>
      </div>
      <div className="card-grid">
        {topBanks.map((bank) => (
          <div key={bank.id} className="card">
            <h4>{bank.name}</h4>
            <div className="big">{fmtScore(bank.score)}</div>
            <div className="muted">{bank.state} • {bank.type.toUpperCase()}</div>
          </div>
        ))}
        {topBanks.length === 0 && <div className="card">No banks to display.</div>}
      </div>
    </section>
  );
}
