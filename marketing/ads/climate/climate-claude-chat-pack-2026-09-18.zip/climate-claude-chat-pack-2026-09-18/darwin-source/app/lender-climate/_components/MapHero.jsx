'use client';
import { useEffect, useMemo, useState } from 'react';
import '../_styles/map.css';
import '../_styles/cards.css';
import AddressSearch from './AddressSearch';
import USAMapSVG from './USAMapSVG';
import SlidePanel from './SlidePanel';
import BankPin from './BankPin';
import { projectPoint } from '../../../lib/projection';

export default function MapHero({ states = [], banks = [], asOf, stale, focusState }) {
  const [activeState, setActiveState] = useState(null);
  const [hoverState, setHoverState] = useState(null);
  const [panelOpen, setPanelOpen] = useState(false);
  const [heatOn, setHeatOn] = useState(true);
  const [userPoint, setUserPoint] = useState(null);
  const [containerSize, setContainerSize] = useState({ width: 800, height: 520 });

  const banksVisible = !!activeState;

  const filteredBanks = useMemo(() => {
    if (!activeState) return [];
    return banks.filter(b => b.state === activeState);
  }, [activeState, banks]);

  const selectedState = states.find(s => s.state === activeState);

  function handleStateClick(code) {
    setActiveState(code);
    setPanelOpen(true);
  }

  function handleBack() {
    setActiveState(null);
    setPanelOpen(false);
  }

  function handleGeocode(result) {
    if (!result?.stateCode) return;
    setActiveState(result.stateCode);
    setPanelOpen(true);
    if (result.lat && result.lng) {
      const point = projectPoint(result.lat, result.lng, containerSize.width, containerSize.height);
      setUserPoint(point);
    }
  }

  useEffect(() => {
    if (focusState && focusState !== activeState) {
      setActiveState(focusState);
      setPanelOpen(true);
    }
  }, [focusState, activeState]);

  return (
    <section className="hero glass fade-in">
      <div className="hero-bg" />
      <div className="hero-surface">
        <div className="top-bar">
          <AddressSearch onResolved={handleGeocode} />
          <div className="legend pill">
            <div className="grad" />
            <span style={{ color: '#e2e8f0', fontSize: 12 }}>Score bands</span>
          </div>
          <button className="btn btn-secondary" onClick={() => setHeatOn(!heatOn)}>
            {heatOn ? 'Heat On' : 'Heat Off'}
          </button>
        </div>
        <div className="map-shell glass" ref={(el) => {
          if (el) {
            const rect = el.getBoundingClientRect();
            if (rect.width && rect.height) setContainerSize({ width: rect.width, height: rect.height });
          }
        }}>
          <USAMapSVG
            states={states}
            heatOn={heatOn}
            activeState={activeState}
            hoverState={hoverState}
            onStateHover={setHoverState}
            onStateClick={handleStateClick}
            banks={banksVisible ? filteredBanks : []}
            containerSize={containerSize}
          />
          {banksVisible && filteredBanks.map((bank) => (
            <BankPin key={bank.id} bank={bank} containerSize={containerSize} />
          ))}
          {userPoint && <div className="user-marker" style={{ left: userPoint.x, top: userPoint.y }} />}
          {panelOpen && (
            <SlidePanel
              stateData={selectedState}
              banks={filteredBanks}
              asOf={asOf}
              stale={stale}
              onClose={handleBack}
              onBack={handleBack}
            />
          )}
        </div>
      </div>
    </section>
  );
}
