'use client';
import { useState } from 'react';
import MapHero from './MapHero';
import NationalMetrics from './NationalMetrics';
import StateTable from './StateTable';
import BankMetrics from './BankMetrics';
import CTASection from './CTASection';

export default function ClimateShell({ climate }) {
  const { national, states, banks, as_of, stale } = climate || {};
  const [focusState, setFocusState] = useState(null);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
      <MapHero states={states} banks={banks} asOf={as_of} stale={stale} focusState={focusState} />
      <NationalMetrics national={national} asOf={as_of} />
      <StateTable states={states} onSelect={setFocusState} />
      <BankMetrics banks={banks} />
      <CTASection />
    </div>
  );
}
