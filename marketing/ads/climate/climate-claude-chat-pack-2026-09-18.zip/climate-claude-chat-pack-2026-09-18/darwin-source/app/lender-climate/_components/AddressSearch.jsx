'use client';
import { useState, useTransition } from 'react';

export default function AddressSearch({ onResolved }) {
  const [query, setQuery] = useState('');
  const [pending, startTransition] = useTransition();
  const [error, setError] = useState(null);

  async function handleSubmit(e) {
    e.preventDefault();
    setError(null);
    startTransition(async () => {
      try {
        const res = await fetch('/api/proxy/geocode', {
          method: 'POST',
          body: JSON.stringify({ q: query }),
          headers: { 'Content-Type': 'application/json' }
        });
        const json = await res.json();
        if (!json.ok) throw new Error(json.reason || 'Failed to geocode');
        onResolved?.(json);
      } catch (err) {
        setError(err.message);
      }
    });
  }

  return (
    <form onSubmit={handleSubmit} className="glass" style={{ padding: 8, display: 'flex', gap: 8, flex: 1 }}>
      <input
        type="text"
        placeholder="Enter city, state or address"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        style={{ flex: 1, background: 'transparent', border: 'none', color: '#e2e8f0', outline: 'none' }}
      />
      <button className="btn" type="submit" disabled={pending}>Go</button>
      {error && <span style={{ color: '#fca5a5', fontSize: 12 }}>{error}</span>}
    </form>
  );
}
