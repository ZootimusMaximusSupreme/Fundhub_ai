"use client";
import { useEffect, useRef, useState } from "react";
import statePaths from "../../../public/maps/us-states-paths.json";
import StateTooltip from "./StateTooltip";
import { scoreToColor } from "../../../lib/colors";

export default function USAMapSVG({
  states = [],
  heatOn,
  activeState,
  hoverState,
  onStateHover,
  onStateClick,
  containerSize,
}) {
  const svgRef = useRef(null);
  const [transform, setTransform] = useState("");
  const [tooltipPos, setTooltipPos] = useState({ x: 0, y: 0 });

  useEffect(() => {
    if (!svgRef.current) return;
    if (!activeState) {
      setTransform("");
      return;
    }

    const svg = svgRef.current;
    const path = svg.querySelector(`path[data-code="${activeState}"]`);
    if (!path) return;

    const box = path.getBBox();
    const w = containerSize?.width || 800;
    const h = containerSize?.height || 500;

    const scale = Math.min(w / box.width, h / box.height) * 0.75;
    const tx = w / 2 - (box.x + box.width / 2) * scale;
    const ty = h / 2 - (box.y + box.height / 2) * scale;

    setTransform(`translate(${tx}px, ${ty}px) scale(${scale})`);
  }, [activeState, containerSize]);

  const stateLookup = Object.fromEntries(states.map((s) => [s.state, s]));

  return (
    <div
      className="usa-map"
      style={{ position: "relative", width: "100%", height: "100%" }}
    >
      <svg ref={svgRef} viewBox="0 0 400 340" style={{ transform }}>
        <g id="states">
          {Object.entries(statePaths).map(([code, d]) => {
            const data = stateLookup[code];
            const fill =
              heatOn && data
                ? scoreToColor(data.score)
                : "rgba(255,255,255,0.08)";
            const opacity =
              activeState && activeState !== code ? 0.35 : 1;

            return (
              <path
                key={code}
                data-code={code}
                d={d}
                className="state-path"
                fill={fill}
                style={{ opacity, cursor: "pointer" }}
                onMouseEnter={(e) => {
                  const rect =
                    svgRef.current?.getBoundingClientRect();
                  onStateHover(code);
                  setTooltipPos({
                    x: e.clientX - rect.left,
                    y: e.clientY - rect.top,
                  });
                }}
                onMouseMove={(e) => {
                  const rect =
                    svgRef.current?.getBoundingClientRect();
                  setTooltipPos({
                    x: e.clientX - rect.left,
                    y: e.clientY - rect.top,
                  });
                }}
                onMouseLeave={() => onStateHover(null)}
                onClick={() => onStateClick(code)}
              />
            );
          })}
        </g>
      </svg>

      {hoverState && stateLookup[hoverState] && (
        <StateTooltip
          state={stateLookup[hoverState]}
          position={tooltipPos}
        />
      )}
    </div>
  );
}
