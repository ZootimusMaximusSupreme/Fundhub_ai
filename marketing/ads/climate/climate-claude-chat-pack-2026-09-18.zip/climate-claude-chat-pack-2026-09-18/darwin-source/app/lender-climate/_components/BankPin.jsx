'use client';
import { projectPoint } from '../../../lib/projection';

export default function BankPin({ bank, containerSize }) {
  const { x, y } = projectPoint(bank.location.lat, bank.location.lng, containerSize.width, containerSize.height);
  return <div className="bank-pin" style={{ left: x, top: y }} title={bank.name} />;
}
