'use client';
import { fmtScore } from '../../../lib/format';
import { scoreToTrend } from '../../../lib/colors';

export default function StateTooltip({ state, position }) {
  if (!state) return null;
  return (
    <div className="tooltip" style={{ left: position.x + 10, top: position.y + 10 }}>
      <div style={{ fontWeight: 700 }}>{state.state}</div>
      <div style={{ fontSize: 12 }}>Score: {fmtScore(state.score)}</div>
      <div style={{ fontSize: 12 }}>Trend: {scoreToTrend(state.trend_30d)}</div>
    </div>
  );
}
