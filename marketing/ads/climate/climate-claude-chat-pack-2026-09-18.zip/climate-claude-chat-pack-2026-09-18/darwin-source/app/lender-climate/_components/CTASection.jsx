import '../_styles/cards.css';

export default function CTASection() {
  return (
    <section className="section">
      <div className="cta">
        <h3 style={{ margin: '0 0 6px' }}>See Your Personalized Funding Odds</h3>
        <p style={{ margin: 0 }}>Upload a credit report to get tailored approvals and appetite signals.</p>
        <div style={{ marginTop: 10 }}>
          <a className="btn" href="#">Upload Credit Report →</a>
        </div>
      </div>
    </section>
  );
}
