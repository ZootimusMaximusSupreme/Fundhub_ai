'use client';
import '../_styles/cards.css';
import { fmtScore, fmtDate } from '../../../lib/format';

export default function NationalMetrics({ national, asOf }) {
  if (!national) return null;
  const entries = national.components ? Object.entries(national.components) : [];
  return (
    <section className="section">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
        <div>
          <div style={{ color: '#94a3b8', fontSize: 12 }}>National Climate</div>
          <div style={{ fontSize: 28, fontWeight: 800 }}>{fmtScore(national.score)}</div>
        </div>
        <div className="pill" style={{ background: national.stale ? 'rgba(239,68,68,0.15)' : 'rgba(34,197,94,0.15)', color: national.stale ? '#f87171' : '#a7f3d0' }}>
          As of {fmtDate(asOf || national.updated_at)}
        </div>
      </div>
      <div className="card-grid">
        {entries.map(([key, value]) => (
          <div className="card" key={key}>
            <h4>{key.replace(/_/g, ' ')}</h4>
            <div className="big">{fmtScore(value)}</div>
            <div className="muted">Component</div>
          </div>
        ))}
      </div>
    </section>
  );
}
