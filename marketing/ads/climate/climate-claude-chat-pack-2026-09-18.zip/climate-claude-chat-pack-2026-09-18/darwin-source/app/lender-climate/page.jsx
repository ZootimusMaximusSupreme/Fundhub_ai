import ClimateShell from './_components/ClimateShell';
import { getClimate } from '../../lib/climateClient';

export const revalidate = 1800;

export default async function LenderClimatePage() {
  let climate;
  try {
    climate = await getClimate();
  } catch (err) {
    climate = { ok: false, reason: err.message };
  }

  if (!climate?.ok) {
    return (
      <main style={{ padding: '18px' }}>
        <div className="card">Temporarily unavailable. {climate?.reason}</div>
      </main>
    );
  }

  return (
    <main style={{ padding: '18px' }}>
      <ClimateShell climate={climate} />
    </main>
  );
}
