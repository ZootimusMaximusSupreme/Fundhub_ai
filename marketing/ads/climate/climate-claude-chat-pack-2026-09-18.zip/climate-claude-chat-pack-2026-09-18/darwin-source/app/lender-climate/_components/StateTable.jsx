'use client';
import { useMemo, useState } from 'react';
import '../_styles/cards.css';
import { fmtScore } from '../../../lib/format';
import { scoreToTrend } from '../../../lib/colors';

export default function StateTable({ states = [], onSelect }) {
  const [sortDir, setSortDir] = useState('desc');

  const rows = useMemo(() => {
    const sorted = [...states].sort((a, b) => sortDir === 'desc' ? b.score - a.score : a.score - b.score);
    return sorted;
  }, [states, sortDir]);

  return (
    <section className="section">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h3 style={{ margin: 0 }}>States</h3>
        <button className="btn btn-secondary" onClick={() => setSortDir(sortDir === 'desc' ? 'asc' : 'desc')}>
          Sort {sortDir === 'desc' ? '↓' : '↑'}
        </button>
      </div>
      <table className="table">
        <thead>
          <tr>
            <th>State</th>
            <th>Score</th>
            <th>Trend</th>
            <th>Issuance</th>
            <th>Approval Odds</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {rows.map((row) => (
            <tr key={row.state}>
              <td>{row.state}</td>
              <td>{fmtScore(row.score)}</td>
              <td>{scoreToTrend(row.trend_30d)}</td>
              <td>{fmtScore(row.issuance_velocity)}</td>
              <td>{row.avg_approval_odds !== undefined ? `${Math.round(row.avg_approval_odds * 100)}%` : '—'}</td>
              <td><button className="btn btn-secondary" onClick={() => onSelect?.(row.state)}>View State</button></td>
            </tr>
          ))}
        </tbody>
      </table>
    </section>
  );
}
