'use client';
import { fmtScore, fmtOdds, fmtDate } from '../../../lib/format';
import { scoreToTrend } from '../../../lib/colors';

export default function SlidePanel({ stateData, banks = [], asOf, stale, onClose, onBack }) {
  if (!stateData) return null;
  return (
    <div className="slide-panel">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
        <div>
          <div style={{ fontSize: 12, color: '#94a3b8' }}>Lending Climate</div>
          <div style={{ fontSize: 22, fontWeight: 700 }}>{stateData.state}</div>
        </div>
        <button className="btn btn-secondary" onClick={onBack}>Back to U.S.</button>
      </div>

      <div className="card" style={{ marginBottom: 12 }}>
        <div style={{ fontSize: 13, color: '#94a3b8' }}>Today&apos;s Score</div>
        <div style={{ fontSize: 32, fontWeight: 800 }}>{fmtScore(stateData.score)}</div>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginTop: 6 }}>
          <span className="pill">{stateData.color_band}</span>
          <span className="pill" style={{ background: stale ? 'rgba(239,68,68,0.15)' : 'rgba(34,197,94,0.15)', color: stale ? '#f87171' : '#a7f3d0' }}>
            {stale ? 'Stale' : 'Fresh'} • As of {fmtDate(asOf || stateData.updated_at)}
          </span>
        </div>
      </div>

      <div className="mini-grid" style={{ marginBottom: 12 }}>
        <Metric label="Approval Odds" value={fmtOdds(stateData.avg_approval_odds)} />
        <Metric label="Trend (30d)" value={scoreToTrend(stateData.trend_30d)} />
        <Metric label="Business Conditions" value={fmtScore(stateData.business_conditions)} />
        <Metric label="Bank Liquidity" value={fmtScore(stateData.liquidity_score)} />
        <Metric label="Issuance Velocity" value={fmtScore(stateData.issuance_velocity)} />
      </div>

      <div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
          <h4 style={{ margin: 0 }}>Banks</h4>
          <span style={{ color: '#94a3b8', fontSize: 12 }}>{banks.length} visible</span>
        </div>
        <div style={{ display: 'grid', gap: 8 }}>
          {banks.slice(0, 12).map((bank) => (
            <div key={bank.id} className="card" style={{ padding: 10 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div>
                  <div style={{ fontWeight: 700 }}>{bank.name}</div>
                  <div style={{ fontSize: 12, color: '#94a3b8' }}>{bank.type.toUpperCase()} • Trend {scoreToTrend(bank.trend_30d)}</div>
                </div>
                <div style={{ fontSize: 20, fontWeight: 800 }}>{fmtScore(bank.score)}</div>
              </div>
            </div>
          ))}
          {banks.length === 0 && <div className="card">No banks to display.</div>}
        </div>
      </div>

      <button className="btn" style={{ width: '100%', marginTop: 16 }} onClick={onClose}>Close Panel</button>
    </div>
  );
}

function Metric({ label, value }) {
  return (
    <div className="card" style={{ padding: 10 }}>
      <div style={{ fontSize: 12, color: '#94a3b8' }}>{label}</div>
      <div style={{ fontSize: 18, fontWeight: 700 }}>{value}</div>
    </div>
  );
}
